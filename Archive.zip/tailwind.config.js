const defaultTheme = require('tailwindcss/defaultTheme');

module.exports = {
  purge: ['src/**/*.js', 'src/**/*.jsx'],
  theme: {
    themeVariants: ['dark'],
    extend: {
      colors: {
        'lightgray': {
          '50': '#ffffff', 
          '100': '#ffffff', 
          '200': '#fefefe', 
          '300': '#fdfdfd', 
          '400': '#fcfcfc', 
          '500': '#fafafa', 
          '600': '#e1e1e1', 
          '700': '#bcbcbc', 
          '800': '#969696', 
          '900': '#7b7b7b'
        },
        'darkgray': {
         ' 50':'#f8fafc',
          '100':'#f1f5f9',
          '200':'#e2e8f0',
          '300':'#cbd5e1',
          '400':'#94a3b8',
          '500':'#64748b',
          '600':'#475569',
          '700':'#334155',
          '800':'#1e293b',
          '900':'#0f172a'
        },
        'purple': {
          '50': '#f9f6ff', 
          '100': '#f4eeff', 
          '200': '#e2d4ff', 
          '300': '#d1baff', 
          '400': '#af86ff', 
          '500': '#8c52ff', 
          '600': '#7e4ae6', 
          '700': '#693ebf', 
          '800': '#543199', 
          '900': '#45287d'
        },
        'orange': {
          '50': '#fff9f4', 
          '100': '#fff2ea', 
          '200': '#fee0c9', 
          '300': '#fdcda9', 
          '400': '#fca769', 
          '500': '#fa8128', 
          '600': '#e17424', 
          '700': '#bc611e', 
          '800': '#964d18', 
          '900': '#7b3f14'
        },
        'green': {
          '50': '#f6fcf8', 
          '100': '#edf8f2', 
          '200': '#d1eedd', 
          '300': '#b6e4c9', 
          '400': '#7fcfa1', 
          '500': '#48bb78', 
          '600': '#41a86c', 
          '700': '#368c5a', 
          '800': '#2b7048', 
          '900': '#235c3b'
        },
        'blue': {
          '50': '#f6fafe', 
          '100': '#ecf5fc', 
          '200': '#d0e6f8', 
          '300': '#b4d6f3', 
          '400': '#7bb8ea', 
          '500': '#4399e1', 
          '600': '#3c8acb', 
          '700': '#3273a9', 
          '800': '#285c87', 
          '900': '#214b6e'
        },
        'darkblue': {
          '50': '#f3f8ff', 
          '100': '#e8f2ff', 
          '200': '#c5ddfe', 
          '300': '#a1c9fd', 
          '400': '#5ba1fc', 
          '500': '#1578fa', 
          '600': '#136ce1', 
          '700': '#105abc', 
          '800': '#0d4896', 
          '900': '#0a3b7b'
        },
        'red': {
          '50': '#fff7f7', 
          '100': '#fef0f0', 
          '200': '#fdd9d9', 
          '300': '#fbc1c1', 
          '400': '#f89393', 
          '500': '#f56565', 
          '600': '#dd5b5b', 
          '700': '#b84c4c', 
          '800': '#933d3d', 
          '900': '#783131'
        },
        'silver': {
          '50': '#fafbfc', 
          '100': '#f6f7f9', 
          '200': '#e7ebef', 
          '300': '#d9dfe6', 
          '400': '#bdc6d3', 
          '500': '#a0aec0', 
          '600': '#909dad', 
          '700': '#788390', 
          '800': '#606873', 
          '900': '#4e555e'
        },
        'gray': {
          '50': '#fafbfc', 
          '100': '#f6f7f9', 
          '200': '#e7ebef', 
          '300': '#d9dfe6', 
          '400': '#bdc6d3', 
          '500': '#a0aec0', 
          '600': '#909dad', 
          '700': '#788390', 
          '800': '#606873', 
          '900': '#4e555e'
        },
        'black': {
          '50': '#f2f2f2', 
          '100': '#e6e6e6', 
          '200': '#bfbfbf', 
          '300': '#999999', 
          '400': '#4d4d4d', 
          '500': '#000000', 
          '600': '#000000', 
          '700': '#000000', 
          '800': '#000000', 
          '900': '#000000'
        },
        'pink': {
          '50': '#fef7fb', 
          '100': '#fdf0f6', 
          '200': '#fbd8e9', 
          '300': '#f8c1db', 
          '400': '#f293c1', 
          '500': '#ed64a6', 
          '600': '#d55a95', 
          '700': '#b24b7d', 
          '800': '#8e3c64', 
          '900': '#743151'
        },
        'teal': {
          '50': '#f5fbfb', 
          '100': '#ebf7f7', 
          '200': '#cdecea', 
          '300': '#afe0de', 
          '400': '#74c9c5', 
          '500': '#38b2ac', 
          '600': '#32a09b', 
          '700': '#2a8681', 
          '800': '#226b67', 
          '900': '#1b5754'
        }
      },
      // fontFamily: {
      //   // poppins: ["Poppins", "sans-serif"],
      //   // adelia: ["ADELIA", "cursive"],
      //   glacial: "'Glacial'",
      //   prodsans: "'Prod Sans'"
      // },
      fontFamily: {
        // sans: ['Poppins', ...defaultTheme.fontFamily.sans],
        sans: ['Prod Sans', ...defaultTheme.fontFamily.sans],
      },
      fontSize: {
        '2.5xl': '1.75rem',
        '45xl': '2.8rem'
      },
      animation: ['hover','group-hover'],
    },
  },
  variants: {
    backgroundColor: ['responsive', 'dark', 'hover', 'group-hover', 'focus'],
    textColor: ['responsive', 'dark', 'hover', 'group-hover', 'focus'],
  },
  plugins: [
    require('tailwindcss-multi-theme'),
    require('tailwind-colors'),
  ],
}
