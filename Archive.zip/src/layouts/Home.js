import React from 'react'
import { Route, Router, Routes } from 'react-router-dom'
import Landing from '../pages/Landing'
import NotFound from '../pages/NotFound'
import RegulatoryServices from '../pages/RegulatoryServices'
import Footer from './Footer'
import Navbar from './Navbar'

const Home = () => {
  return (
    <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/rs" element={<RegulatoryServices />} />
          <Route path="/*" element={<NotFound />} />
        </Routes>
        <Footer />
      </Router>
  )
}

export default Home