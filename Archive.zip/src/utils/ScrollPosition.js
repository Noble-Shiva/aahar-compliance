import { useEffect } from 'react';

const ScrollPosition = () => {

    useEffect(() => {
        window.addEventListener('scroll', scrollPosition);
        return () => window.removeEventListener('scroll', scrollPosition)
    }, []);

    const scrollPosition = () => {
        const winScroll =
        document.body.scrollTop || document.documentElement.scrollTop

        const height =
            document.documentElement.scrollHeight -
            document.documentElement.clientHeight

        const scrolled = winScroll / height

        console.log(scrolled.toFixed(2));
    }
    
    return (null);

}

export default ScrollPosition