import { CheckCircleIcon } from '@heroicons/react/solid'
import React from 'react'

const Review = () => {
    return (
        <div class="p-5 rounded-md shadow-lg bg-white">
            <div class="flex space-x-0.5">Stars Here</div>
            <p class="text-sm font-medium leading-5 text-gray-500">2 days ago</p>
            <div class="mt-3 space-y-1">
                <h3 class="font-semibold text-gray-800">
                    Awesome Course
                </h3>
                <p class="text-sm font-medium leading-5 text-gray-600">
                    As always, Tony delivers best explanations about the ‘under the hood’ mechanism of JS ( ES6+ ). It’s a must buy course for those who watched ( and certainly learned a lot ) JavaScript: Understanding the Weird Parts
                </p>
            </div>
            <div class="mt-3 flex items-center space-x-2">
                <div class="flex flex-shrink-0 rounded-full border border-gray-200">
                    <img class="w-8 h-8 object-cover rounded-full" alt=""/>
                </div>
                <span class="text-sm font-semibold leading-5 text-gray-900">
                    Shiva
                    </span>
                    <CheckCircleIcon className='w-5 h-5 text-gray-600'></CheckCircleIcon>
            </div>
        </div>
    )
}

export default Review