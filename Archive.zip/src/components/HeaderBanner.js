import React from 'react';
import { SpeakerphoneIcon, XIcon } from '@heroicons/react/outline';

const HeaderBanner = ({ onClose}) => {
    return (
        <div
            style={{ background: '#2f2e41' }}
            // className="sticky top-0 x-50"
        >
            <div className="max-w-6xl mx-auto py-3 px-3 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between flex-wrap">
                    <div className="w-0 flex-1 flex items-center sm:justify-center">
                        <span className="flex rounded-lg bg-white" style={{padding: '0.5rem'}}>
                            <SpeakerphoneIcon className="h-5 w-5" style={{color: '#2f2e41'}} aria-hidden="true" />
                        </span>
                        <p className="ml-3 font-medium text-white truncate">
                            <span className="md:hidden">We announced a new product!</span>
                            <span className="hidden md:inline">Big news! We're excited to announce a brand new product.</span>
                        </p>
                        <div className="hidden sm:block ml-3 mt-2 flex-shrink-0 w-full sm:order-2 sm:mt-0 sm:w-auto">
                            <a
                                style={{color: '#2f2e41'}}
                                href="/"
                                className="flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-white hover:bg-purple-50">
                                Learn more
                            </a>
                        </div>
                    </div>
                    <div className="sm:hidden order-3 mt-2 flex-shrink-0 w-full sm:order-2 sm:mt-0">
                        <a
                            style={{color: '#2f2e41'}}
                            href="/"
                            className="w-1/4 sm:w-auto m-auto flex items-center justify-center px-2 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-white hover:bg-purple-50">
                            Learn more
                        </a>
                    </div>
                    <div className="order-2 flex-shrink-0 sm:order-3 sm:ml-3">
                        <button
                            onClick={onClose}
                            type="button"
                            className="-mr-1 flex p-2 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-white sm:-mr-2">
                                <span className="sr-only">Dismiss</span>
                                <XIcon className="h-6 w-6" aria-hidden="true" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default HeaderBanner;