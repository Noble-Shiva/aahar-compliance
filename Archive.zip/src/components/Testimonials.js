import React from 'react'

const Testimonials = () => {
    return (
    
        <div className="leanding-normal tracking-wide py-5">

            <h1 className="mt-4 text-sm leading-7 tracking-wide text-gray-700 font-regular">
                TESTIMONIALS
            </h1>
            <h1 className="text-3xl md:text-4xl lg:text-5xl leading-normal font-extrabold tracking-tight text-gray-900">
                What our <span className="text-purple-600">Clients say?</span>
            </h1>

            <div className="container mx-auto w-full overflow-hidden relative">
                <div className="w-full h-full absolute">
                    <div className="w-1/6 h-full absolute z-40 left-0" style={{ background: 'linear-gradient(to right, #ffffff 0%, rgba(255, 255, 255, 0) 100%)' }}></div>
                    <div className="w-1/6 h-full absolute z-40 right-0" style={{ background: 'linear-gradient(to left, #ffffff 0%, rgba(255, 255, 255, 0) 100%)' }}></div>
                </div>

                <div className="carousel-items flex items-center justify-center" style={{ width: 'fit-content', animation: 'carouselAnim 10s infinite alternate linear' }}>

                    <div className="w-64 h-64 carousel-focus flex items-center flex-col relative bg-white mx-5 my-10 px-4 py-3 rounded-lg shadow-lg">
                        <h3 className="text-purple-400 font-bold text-xl mb-3">Name</h3>
                        <img className="h-16 w-16 rounded-full shadow-2xl" src="https://pbs.twimg.com/profile_images/830533062807191552/TbkWKnnv_400x400.jpg" alt="Img" />
                        <p className="mt-10 tracking-wide text-gray-700 text-center">"Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, quibusdam!"</p>
                    </div>

                    <div className="w-64 h-64 carousel-focus flex items-center flex-col relative bg-white mx-5 my-10 px-4 py-3 rounded-lg shadow-lg">
                        <h3 className="text-purple-400 font-bold text-xl mb-3">Name</h3>
                        <img className="h-16 w-16 rounded-full shadow-2xl" src="https://pbs.twimg.com/profile_images/830533062807191552/TbkWKnnv_400x400.jpg" alt="Img" />
                        <p className="mt-10 tracking-wide text-gray-700 text-center">"Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, quibusdam!"</p>
                    </div>

                    <div className="w-64 h-64 carousel-focus flex items-center flex-col relative bg-white mx-5 my-10 px-4 py-3 rounded-lg shadow-lg">
                        <h3 className="text-purple-400 font-bold text-xl mb-3">Name</h3>
                        <img className="h-16 w-16 rounded-full shadow-2xl" src="https://pbs.twimg.com/profile_images/830533062807191552/TbkWKnnv_400x400.jpg" alt="Img" />
                        <p className="mt-10 tracking-wide text-gray-700 text-center">"Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, quibusdam!"</p>
                    </div>

                    <div className="w-64 h-64 carousel-focus flex items-center flex-col relative bg-white mx-5 my-10 px-4 py-3 rounded-lg shadow-lg">
                        <h3 className="text-purple-400 font-bold text-xl mb-3">Name</h3>
                        <img className="h-16 w-16 rounded-full shadow-2xl" src="https://pbs.twimg.com/profile_images/830533062807191552/TbkWKnnv_400x400.jpg" alt="Img" />
                        <p className="mt-10 tracking-wide text-gray-700 text-center">"Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, quibusdam!"</p>
                    </div>

                    <div className="w-64 h-64 carousel-focus flex items-center flex-col relative bg-white mx-5 my-10 px-4 py-3 rounded-lg shadow-lg">
                        <h3 className="text-purple-400 font-bold text-xl mb-3">Name</h3>
                        <img className="h-16 w-16 rounded-full shadow-2xl" src="https://pbs.twimg.com/profile_images/830533062807191552/TbkWKnnv_400x400.jpg" alt="Img" />
                        <p className="mt-10 tracking-wide text-gray-700 text-center">"Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, quibusdam!"</p>
                    </div>
                    
                    <div className="w-64 h-64 carousel-focus flex items-center flex-col relative bg-white mx-5 my-10 px-4 py-3 rounded-lg shadow-lg">
                        <h3 className="text-purple-400 font-bold text-xl mb-3">Name</h3>
                        <img className="h-16 w-16 rounded-full shadow-2xl" src="https://pbs.twimg.com/profile_images/830533062807191552/TbkWKnnv_400x400.jpg" alt="Img" />
                        <p className="mt-10 tracking-wide text-gray-700 text-center">"Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, quibusdam!"</p>
                    </div>

                    <div className="w-64 h-64 carousel-focus flex items-center flex-col relative bg-white mx-5 my-10 px-4 py-3 rounded-lg shadow-lg">
                        <h3 className="text-purple-400 font-bold text-xl mb-3">Name</h3>
                        <img className="h-16 w-16 rounded-full shadow-2xl" src="https://pbs.twimg.com/profile_images/830533062807191552/TbkWKnnv_400x400.jpg" alt="Img" />
                        <p className="mt-10 tracking-wide text-gray-700 text-center">"Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, quibusdam!"</p>
                    </div>

                    <div className="w-64 h-64 carousel-focus flex items-center flex-col relative bg-white mx-5 my-10 px-4 py-3 rounded-lg shadow-lg">
                        <h3 className="text-purple-400 font-bold text-xl mb-3">Name</h3>
                        <img className="h-16 w-16 rounded-full shadow-2xl" src="https://pbs.twimg.com/profile_images/830533062807191552/TbkWKnnv_400x400.jpg" alt="Img" />
                        <p className="mt-10 tracking-wide text-gray-700 text-center">"Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, quibusdam!"</p>
                    </div>
                </div>
            </div>
        </div>
  )
}

export default Testimonials