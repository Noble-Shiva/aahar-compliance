import React, { useState, useRef, useEffect } from 'react';
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import { Link } from 'react-router-dom';
import { courses } from '../pages/CourseCatalog';

// Data
const data = [
      {
        "title": "Find me on Twitter",
        "link": "https://twitter.com/kendalmintcode",
        "imageUrl": "https://placeimg.com/300/300/any"
      },
      {
        "title": "Welcome to Ark Labs",
        "link": "https://ark-labs.co.uk",
        "imageUrl": "https://placeimg.com/300/300/animals"
      },
      {
        "title": "Some sort of third title",
        "link": "https://twitter.com/kendalmintcode",
        "imageUrl": "https://placeimg.com/300/300/architecture"
      },
      {
        "title": "A personal site perhaps?",
        "link": "https://robkendal.co.uk",
        "imageUrl": "https://placeimg.com/300/300/nature"
      },
      {
        "title": "Super item number five",
        "link": "https://twitter.com/kendalmintcode",
        "imageUrl": "https://placeimg.com/300/300/people"
      },
      {
        "title": "Super item number six",
        "link": "https://twitter.com/kendalmintcode",
        "imageUrl": "https://placeimg.com/300/300/tech"
      },
      {
        "title": "Super item number seven",
        "link": "https://twitter.com/kendalmintcode",
        "imageUrl": "https://placeimg.com/300/300/animals"
      },
      {
        "title": "Super item number eight",
        "link": "https://twitter.com/kendalmintcode",
        "imageUrl": "https://placeimg.com/300/300/people"
      },
      {
        "title": "Super item number the last",
        "link": "https://twitter.com/kendalmintcode",
        "imageUrl": "https://placeimg.com/300/300/tech"
      }
]

const responsive = {
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 4,
    slidesToSlide: 4 // optional, default to 1.
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
    slidesToSlide: 2 // optional, default to 1.
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
    slidesToSlide: 1 // optional, default to 1.
  }
};

const CarouselComponent = () => {
//   const maxScrollWidth = useRef(0);
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const carousel = useRef(null);

//   const movePrev = () => {
//     if (currentIndex > 0) {
//       setCurrentIndex((prevState) => prevState - 1);
//     }
//   };

//   const moveNext = () => {
//     if (
//       carousel.current !== null &&
//       carousel.current.offsetWidth * currentIndex <= maxScrollWidth.current
//     ) {
//       setCurrentIndex((prevState) => prevState + 1);
//     }
//   };

//   const isDisabled = (direction) => {
//     if (direction === 'prev') {
//       return currentIndex <= 0;
//     }

//     if (direction === 'next' && carousel.current !== null) {
//       return (
//         carousel.current.offsetWidth * currentIndex >= maxScrollWidth.current
//       );
//     }

//     return false;
//   };

//   useEffect(() => {
//     if (carousel !== null && carousel.current !== null) {
//       carousel.current.scrollLeft = carousel.current.offsetWidth * currentIndex;
//     }
//   }, [currentIndex]);

//   useEffect(() => {
//     maxScrollWidth.current = carousel.current
//       ? carousel.current.scrollWidth - carousel.current.offsetWidth
//       : 0;
//   }, []);

  return (
    <div className="carousel my-12 mx-auto">
      {/* <h2 className="text-4xl leading-8 font-semibold mb-12 text-slate-700">
        Our epic carousel
      </h2>
      <div className="relative overflow-hidden">
        <div className="flex justify-between absolute top left w-full h-full">
          <button
            onClick={movePrev}
            className="hover:bg-blue-900/75 text-white w-10 h-full text-center opacity-75 hover:opacity-100 disabled:opacity-25 disabled:cursor-not-allowed z-10 p-0 m-0 transition-all ease-in-out duration-300"
            disabled={isDisabled('prev')}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-12 w-20 -ml-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M15 19l-7-7 7-7"
              />
            </svg>
            <span className="sr-only">Prev</span>
          </button>
          <button
            onClick={moveNext}
            className="hover:bg-blue-900/75 text-white w-10 h-full text-center opacity-75 hover:opacity-100 disabled:opacity-25 disabled:cursor-not-allowed z-10 p-0 m-0 transition-all ease-in-out duration-300"
            disabled={isDisabled('next')}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-12 w-20 -ml-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M9 5l7 7-7 7"
              />
            </svg>
            <span className="sr-only">Next</span>
          </button>
        </div>
        <div
          ref={carousel}
          className="carousel-container relative flex gap-1 overflow-hidden scroll-smooth snap-x snap-mandatory touch-pan-x z-0"
        >
          {data.resources.map((resource, index) => {
            return (
              <div
                key={index}
                className="carousel-item text-center relative w-64 h-64 snap-start"
              >
                <a
                  href={resource.link}
                  className="h-full w-full aspect-square block bg-origin-padding bg-left-top bg-cover bg-no-repeat z-0"
                  style={{ backgroundImage: `url(${resource.imageUrl || ''})` }}
                >
                  <img
                    src={resource.imageUrl || ''}
                    alt={resource.title}
                    className="w-full aspect-square hidden"
                  />
                </a>
                <a
                  href={resource.link}
                  className="h-full w-full aspect-square block absolute top-0 left-0 transition-opacity duration-300 opacity-0 hover:opacity-100 bg-blue-800/75 z-10"
                >
                  <h3 className="text-white py-6 px-3 mx-auto text-xl">
                    {resource.title}
                  </h3>
                </a>
              </div>
            );
          })}
        </div>
      </div> */}
        <Carousel
            swipeable={true}
            draggable={false}
            showDots={true}
            responsive={responsive}
            // ssr={true} // means to render carousel on server-side.
            // infinite={true}
            autoPlay={false}
            shouldResetAutoplay={false} 
            autoPlaySpeed={1000}
            keyBoardControl={true}
            customTransition="all .5"
            transitionDuration={500}
            containerClass="carousel-container"
            // removeArrowOnDeviceType={["tablet", "mobile"]}
            deviceType={window.innerWidth > 480 ? window.innerWidth >= 1024 ? "desktop" : "tablet" : "mobile"}
            dotListClass="custom-dot-list-style"
            itemClass="carousel-item"
          >
                {courses.map((course) => (
                    <div key={course.courseName} className="group relative p-5">
                        <div className="w-full min-h-40 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-40 lg:aspect-none">
                            <img
                                src={'https://placeimg.com/300/300/tech'}
                                alt={course.imageAlt}
                                className="w-full h-full object-center object-cover lg:w-full lg:h-full"
                            />
                        </div>
                        <div className="mt-4 flex justify-between">
                            <div>
                                <h3 className="text-sm text-gray-700 two-line-ellipsis">
                                    <a href={course.href} className="text-lg text-gray-900 font-semibold">
                                        <span aria-hidden="true" className="absolute inset-0" />
                                        {course.courseName}
                                    </a>
                                </h3>
                                <p className="mt-1 text-md text-gray-500">Trainer: {course.trainer}</p>
                                <p className="mt-2">
                                    <span className="text-xl font-bold">₹ {course.fees}</span>
                                    {/* <span className="ml-2 text-gray-700 font-semibold">per licence</span> */}
                                </p>
                                <div className='mt-8'>
                                    <Link to="/checkout" className="text-white bg-orange-500 hover:text-white hover:bg-orange-600 mt-2 px-6 py-4 text-sm font-semibold leading-4 text-center rounded-lg shadow-md">Buy Now</Link>
                                </div>
                            </div>
                            {/* <p className="text-sm font-medium text-gray-900">{course.fees}</p> */}
                        </div>
                    </div>
                ))}
        </Carousel>
    </div>
  );
};

export default CarouselComponent;
