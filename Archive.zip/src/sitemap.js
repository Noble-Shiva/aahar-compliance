// const { SitemapStream, streamToPromise } = require('sitemap');
// const { Readable } = require('stream');

// export default async (req, res) => {

//     // An array with your links
//     const links = [
//         { url: 'https://aaharventures.com', changefreq: 'daily', priority: 0.3 },
//     ]
    
//     // Create a stream to write to
//     const stream = new SitemapStream({ hostname: `https://${ req.headers.host }` });

//     req.writeHead(200, {
//         "Content-Type": "application/xml"
//     })
    
//     // Return a promise that resolves with your XML string
//     const xmlString = streamToPromise(Readable.from(links).pipe(stream)).then((data) =>
//       data.toString()
//     )

//     res.send(xmlString);
// }


// import Generator from 'react-router-sitemap-generator';
// import Router from './App'; //import your react router component

// const generator = new Generator(
//   'https://react-router-sitemap-generator.com',
//   Router(),
//   {
//     lastmod: new Date().toISOString().slice(0, 10),
//     changefreq: 'monthly',
//     priority: 0.8,
//   }
// );
// generator.save('public/sitemap.xml');

const { SitemapStream, streamToPromise } = require( 'sitemap' )
const { Readable } = require( 'stream' )

// An array with your links
const links = [{ url: '/page-1/',  changefreq: 'daily', priority: 0.3  }]

// Create a stream to write to
const stream = new SitemapStream( { hostname: 'https://aaharventures.com/' } )

// Return a promise that resolves with your XML string
return streamToPromise(Readable.from(links).pipe(stream)).then((data) =>
  data.toString()
)